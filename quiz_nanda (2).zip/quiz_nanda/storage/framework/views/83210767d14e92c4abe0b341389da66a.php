
<?php $__env->startSection('content'); ?>

<h2>Categories</h2>

<a href="<?php echo e(url('categories/create')); ?>" class="btn btn-primary mb-3 float-end">Add Category</a>

<table class="table table-bordered">
      <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($row->cat_id); ?></td>
                  <td><?php echo e($row->cat_name); ?></td>
                  <td><a href="<?php echo e(url('categories/edit/' . $row->cat_id)); ?>" class="btn btn-warning">Edit</a></td>
                  <td>
                        <form action="<?php echo e(url('categories/' . $row->cat_id)); ?>" method="post">
                              <input type="hidden" name="_method" value="DELETE">
                              <?php echo csrf_field(); ?>
                              <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Are you sure?')">
                        </form>
                  </td>
            </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-project11\resources\views/categories/index.blade.php ENDPATH**/ ?>