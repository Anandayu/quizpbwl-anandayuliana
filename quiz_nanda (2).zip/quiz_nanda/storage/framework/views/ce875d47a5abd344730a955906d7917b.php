

<?php $__env->startSection('content'); ?>
    <h2>Add Golongan</h2>

    <form action="<?php echo e(url('golongan')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">KODE</label>
            <input type="text" name="gol_kode" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">NAMA</label>
            <input type="text" name="gol_nama" id="" class="form-control">
        </div>
        <div class="mb-3">
            <input type="submit" value="SAVE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quiz_nanda\resources\views/golongan/create.blade.php ENDPATH**/ ?>